#!/usr/bin/env bash
set -euo pipefail
cd /home/yongyong0206/paper_search/paper_download
export SEED_PROFILE=/home/yongyong0206/paper_search/paper_download/outputs/linux_seed_profile_from_docs/linux_chromium_user_data_seed
export PROFILE_NAME=Default
export CHROME_PATH=/home/yongyong0206/chrome-linux/chrome-linux64/chrome
export XVFB_BIN=/home/yongyong0206/.local/bin/Xvfb
export XVFB_DISPLAY=:99
export XVFB_SCREEN=1280x1024x24
export XVFB_LOG_FILE=/home/yongyong0206/paper_search/paper_download/logs/drission_startup_verify_20260319_210654.xvfb.log
exec /home/yongyong0206/paper_search/paper_download/scripts/with_xvfb.sh -- /home/yongyong0206/paper_search/paper_download/.venv/bin/python3 /home/yongyong0206/paper_search/paper_download/experiment/run_linux_headless_suite.py --suite full --run-dir /home/yongyong0206/paper_search/paper_download/outputs/linux_headless_suite_runs/drission_startup_verify_20260319_210654 --persistent-profile-dir /home/yongyong0206/paper_search/paper_download/outputs/linux_seed_profile_from_docs/linux_chromium_user_data_seed --profile-name Default --runtime-preset linux_cli_seeded --execution-env linux_server --headless 0 --landing-workers 2 --download-workers 3 --after-first-pass stop --sample-csv /home/yongyong0206/paper_search/paper_download/outputs/benchmark_inputs/publisher_download_benchmark_startup_verify_20260319.csv --execute
