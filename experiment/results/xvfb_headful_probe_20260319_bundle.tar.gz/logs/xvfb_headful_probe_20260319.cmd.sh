#!/usr/bin/env bash
set -euo pipefail
cd /home/yongyong0206/paper_search/paper_download
export SEED_PROFILE=/home/yongyong0206/paper_search/paper_download/outputs/linux_seed_profile_from_docs/linux_chromium_user_data_seed
export PROFILE_NAME=Default
export CHROME_PATH=/home/yongyong0206/chrome-linux/chrome-linux64/chrome
export XVFB_BIN=/home/yongyong0206/.local/bin/Xvfb
export XVFB_DISPLAY=:99
export XVFB_SCREEN=1280x1024x24
export XVFB_LOG_FILE=/home/yongyong0206/paper_search/paper_download/logs/xvfb_headful_probe_20260319.xvfb.log
exec /home/yongyong0206/paper_search/paper_download/scripts/with_xvfb.sh -- /home/yongyong0206/paper_search/paper_download/.venv/bin/python3 /home/yongyong0206/paper_search/paper_download/experiment/run_linux_headless_suite.py --suite pilot --run-dir /home/yongyong0206/paper_search/paper_download/outputs/linux_headless_suite_runs/xvfb_headful_probe_20260319 --persistent-profile-dir /home/yongyong0206/paper_search/paper_download/outputs/linux_seed_profile_from_docs/linux_chromium_user_data_seed --profile-name Default --runtime-preset linux_cli_seeded --execution-env linux_server --headless 0 --landing-workers 1 --download-workers 1 --after-first-pass stop --sample-csv outputs/_aip_structural_validation_20260315_input.csv --execute
