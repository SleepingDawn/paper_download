# Linux Headless Experiment Summary

- suite: `pilot`
- sample_total: `2`
- recent_year_floor: `2024`
- recent_primary_total: `0`
- legacy_fallback_total: `0`
- landing_probe_records: `2`
- download_records: `2`

## Overall Buckets

### Landing Probe
- landing_success: 1
- challenge_or_interstitial: 1
- blank_or_incomplete: 0
- timeout_or_error: 0
- environment_or_config_failure: 0
- access_rights: 0
- doi_not_found: 0
- missing: 0
- other_non_success: 0

### Download

- publisher_native_download: 0
- scihub_assisted_download: 0
- download_success_unknown: 0
- landing_success_no_download: 0
- challenge_or_interstitial: 1
- blank_or_incomplete: 0
- timeout_or_error: 1
- environment_or_config_failure: 0
- access_rights: 0
- doi_not_found: 0
- missing: 0
- other_non_success: 0

## Validation Cohorts

- unknown: 2

## Retry Protection

- repeated_attempt: 2

## Combined

- challenge_or_interstitial: 1
- timeout_or_error: 1

## Cohort Breakdown

- unknown: {"challenge_or_interstitial": 1, "timeout_or_error": 1}

## Publisher Breakdown

- Other (other): sample=2, landing_success=1, publisher_native=0, scihub=0, unknown_success=0, landing_success_no_download=0, env_fail=0
