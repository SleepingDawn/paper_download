# Landing Experiment Summary

- Sample size: 2
- Publishers covered: American Institute of Physic, American Institute of Physics
- Legacy success-like count: 1
- Legacy reclassified as non-success: 0

## Counts by Classifier State
- challenge_detected: 1
- success_landing: 1

## Representative Failure Reasons
- content_populated: 1
- doi_match: 1
- expected_domain_match: 1
- publisher_marker_present: 1
- strong_meta_present: 1
- fail_block_bot_signal: 1
- url_marker=challenge_or_bot: 1

## Remaining Weak Spots
- Challenge pages remain a hard stop. [blocked] No CAPTCHA, Turnstile, or Cloudflare bypass is implemented.
