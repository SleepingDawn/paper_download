# Linux Headless Experiment Summary

- suite: `full`
- sample_total: `7`
- recent_year_floor: `2024`
- recent_primary_total: `0`
- legacy_fallback_total: `0`
- landing_probe_records: `7`
- download_records: `7`

## Overall Buckets

### Landing Probe
- landing_success: 4
- challenge_or_interstitial: 0
- blank_or_incomplete: 0
- timeout_or_error: 0
- environment_or_config_failure: 0
- access_rights: 0
- doi_not_found: 0
- missing: 0
- other_non_success: 3

### Download

- publisher_native_download: 5
- scihub_assisted_download: 0
- download_success_unknown: 0
- landing_success_no_download: 0
- challenge_or_interstitial: 0
- blank_or_incomplete: 0
- timeout_or_error: 2
- environment_or_config_failure: 0
- access_rights: 0
- doi_not_found: 0
- missing: 0
- other_non_success: 0

## Validation Cohorts

- unknown: 7

## Retry Protection

- repeated_attempt: 7

## Combined

- publisher_native_download: 5
- timeout_or_error: 2

## Cohort Breakdown

- unknown: {"publisher_native_download": 5, "timeout_or_error": 2}

## Publisher Breakdown

- Elsevier BV (elsevier): sample=2, landing_success=2, publisher_native=2, scihub=0, unknown_success=0, landing_success_no_download=0, env_fail=0
- American Institute of Physics (aip): sample=2, landing_success=0, publisher_native=0, scihub=0, unknown_success=0, landing_success_no_download=0, env_fail=0
- IOP Publishing (iop): sample=1, landing_success=0, publisher_native=1, scihub=0, unknown_success=0, landing_success_no_download=0, env_fail=0
- Institute of Electrical and Electronics Engineers (ieee): sample=1, landing_success=1, publisher_native=1, scihub=0, unknown_success=0, landing_success_no_download=0, env_fail=0
- Other (other): sample=1, landing_success=1, publisher_native=1, scihub=0, unknown_success=0, landing_success_no_download=0, env_fail=0
