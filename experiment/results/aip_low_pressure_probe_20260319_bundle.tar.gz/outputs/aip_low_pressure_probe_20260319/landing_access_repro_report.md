# Landing Experiment Summary

- Sample size: 2
- Publishers covered: American Institute of Physic, American Institute of Physics
- Legacy success-like count: 0
- Legacy reclassified as non-success: 0

## Counts by Classifier State
- challenge_detected: 1
- network_error: 1

## Representative Failure Reasons
- navigation_network_error: 1
- 
The connection to the page has been disconnected.
Version: 4.1.1.2: 1
- page_disconnected_during_main_navigation: 1
- fail_block_bot_signal: 1
- url_marker=challenge_or_bot: 1

## Remaining Weak Spots
- Challenge pages remain a hard stop. [blocked] No CAPTCHA, Turnstile, or Cloudflare bypass is implemented.
